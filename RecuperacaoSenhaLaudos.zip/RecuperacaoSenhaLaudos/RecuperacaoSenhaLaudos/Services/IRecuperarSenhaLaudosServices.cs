﻿namespace RecuperacaoSenhaLaudos.Services
{
    public interface IRecuperarSenhaLaudosServices
    {
        Task BuscarSenhasLaudos(DTOs.BuscarSenhasLaudos createExpensiveDTO);

    }
}
